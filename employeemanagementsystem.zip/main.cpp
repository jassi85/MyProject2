#include <iostream>
#include <fstream>
#include <map>
#include <iomanip>
#include <sstream>
using namespace std;

struct Employee
{
    int id;
    string name;
    string department;
    string address;
    string contact;
    double salary;
};

map<int, Employee> employees;
string filename = "employees.txt";
int nextID = 1001;

void loadEmployees()
{
    ifstream file(filename);
    if (!file) return;

    string line;

    while (getline(file, line))
    {
        stringstream ss(line);
        Employee emp;
        string temp;

        getline(ss, temp, '|'); emp.id = stoi(temp);
        getline(ss, emp.name, '|');
        getline(ss, emp.department, '|');
        getline(ss, emp.address, '|');
        getline(ss, emp.contact, '|');
        getline(ss, temp, '|'); emp.salary = stod(temp);

        employees[emp.id] = emp;

        if (emp.id >= nextID)
            nextID = emp.id + 1;
    }

    file.close();
}

void saveEmployees()
{
    ofstream file(filename);

    for (auto &p : employees)
    {
        Employee emp = p.second;

        file << emp.id << "|"
             << emp.name << "|"
             << emp.department << "|"
             << emp.address << "|"
             << emp.contact << "|"
             << emp.salary << endl;
    }

    file.close();
}

void displayEmployees()
{
    if (employees.empty())
    {
        cout << "No employees found.\n";
        return;
    }

    cout << "\n--------------------------------------------------------------------------------------------------\n";
    cout << left << setw(6) << "ID"
         << setw(15) << "Name"
         << setw(15) << "Department"
         << setw(20) << "Address"
         << setw(15) << "Contact"
         << setw(10) << "Salary" << endl;
    cout << "--------------------------------------------------------------------------------------------------\n";

    for (auto &p : employees)
    {
        Employee emp = p.second;

        cout << left << setw(6) << emp.id
             << setw(15) << emp.name
             << setw(15) << emp.department
             << setw(20) << emp.address
             << setw(15) << emp.contact
             << setw(10) << emp.salary << endl;
    }

    cout << "--------------------------------------------------------------------------------------------------\n";
}

void addEmployee()
{
    Employee emp;

    emp.id = nextID++;

    cin.ignore();

    cout << "Enter Name: ";
    getline(cin, emp.name);

    cout << "Enter Department: ";
    getline(cin, emp.department);

    cout << "Enter Address: ";
    getline(cin, emp.address);

    cout << "Enter Contact Number: ";
    getline(cin, emp.contact);

    cout << "Enter Salary: ";
    cin >> emp.salary;

    employees[emp.id] = emp;

    saveEmployees();

    cout << "\nEmployee Added Successfully\n";
    cout << "Generated Employee ID: " << emp.id << endl;
}

void searchEmployee()
{
    int id;

    cout << "Enter Employee ID: ";
    cin >> id;

    if (!employees.count(id))
    {
        cout << "Employee not found.\n";
        return;
    }

    Employee emp = employees[id];

    cout << "\nEmployee Details\n";
    cout << "ID: " << emp.id << endl;
    cout << "Name: " << emp.name << endl;
    cout << "Department: " << emp.department << endl;
    cout << "Address: " << emp.address << endl;
    cout << "Contact: " << emp.contact << endl;
    cout << "Salary: " << emp.salary << endl;
}

void updateEmployee()
{
    int id;

    cout << "Enter Employee ID to update: ";
    cin >> id;

    if (!employees.count(id))
    {
        cout << "Employee not found.\n";
        return;
    }

    cin.ignore();

    cout << "Enter new name: ";
    getline(cin, employees[id].name);

    cout << "Enter new department: ";
    getline(cin, employees[id].department);

    cout << "Enter new address: ";
    getline(cin, employees[id].address);

    cout << "Enter new contact: ";
    getline(cin, employees[id].contact);

    cout << "Enter new salary: ";
    cin >> employees[id].salary;

    saveEmployees();

    cout << "Employee updated successfully.\n";
}

void deleteEmployee()
{
    int id;

    cout << "Enter Employee ID to delete: ";
    cin >> id;

    if (employees.erase(id))
    {
        saveEmployees();
        cout << "Employee deleted successfully.\n";
    }
    else
        cout << "Employee not found.\n";
}

void increaseSalary()
{
    int id;
    double amount;

    cout << "Enter Employee ID: ";
    cin >> id;

    if (!employees.count(id))
    {
        cout << "Employee not found.\n";
        return;
    }

    cout << "Enter amount to increase: ";
    cin >> amount;

    employees[id].salary += amount;

    saveEmployees();

    cout << "Salary increased. New salary: " << employees[id].salary << endl;
}

void decreaseSalary()
{
    int id;
    double amount;

    cout << "Enter Employee ID: ";
    cin >> id;

    if (!employees.count(id))
    {
        cout << "Employee not found.\n";
        return;
    }

    cout << "Enter amount to decrease: ";
    cin >> amount;

    if (amount > employees[id].salary)
    {
        cout << "Invalid amount.\n";
        return;
    }

    employees[id].salary -= amount;

    saveEmployees();

    cout << "Salary decreased. New salary: " << employees[id].salary << endl;
}

bool login()
{
    string username, password;

    cout << "Admin Login\n";
    cout << "Username: ";
    cin >> username;

    cout << "Password: ";
    cin >> password;

    if (username == "Jash" && password == "Sj_123")
        return true;

    return false;
}

void menu()
{
    int choice;

    do
    {
        cout << "\n=========== Employee Management System ===========\n";
        cout << "1. Add Employee\n";
        cout << "2. Display Employees\n";
        cout << "3. Search Employee\n";
        cout << "4. Update Employee\n";
        cout << "5. Delete Employee\n";
        cout << "6. Increase Salary\n";
        cout << "7. Decrease Salary\n";
        cout << "8. Exit\n";

        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1: addEmployee(); break;
        case 2: displayEmployees(); break;
        case 3: searchEmployee(); break;
        case 4: updateEmployee(); break;
        case 5: deleteEmployee(); break;
        case 6: increaseSalary(); break;
        case 7: decreaseSalary(); break;
        case 8: cout << "Exiting...\n"; break;
        default: cout << "Invalid choice\n";
        }

    } while (choice != 8);
}

int main()
{
    loadEmployees();

    if (!login())
    {
        cout << "Invalid Login!\n";
        return 0;
    }

    menu();

    return 0;
}